//
//  foundation_pokedexTests.swift
//  foundation_pokedexTests
//
//  Created by Diego Saragoza Da Silva on 18/03/25.
//

import Testing
@testable import foundation_pokedex

struct foundation_pokedexTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
