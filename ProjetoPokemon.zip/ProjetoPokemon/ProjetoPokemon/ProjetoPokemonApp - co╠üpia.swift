//
//  ProjetoPokemonApp.swift
//  ProjetoPokemon
//
//  Created by Aluno Mack on 19/03/25.
//

import SwiftUI

@main
struct ProjetoPokemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
