//
//  PokedexView.swift
//  foundation_pokedex
//
//  Created by Diego Saragoza Da Silva on 18/03/25.
//

import SwiftUI

struct PokedexView : View {
    var body : some View {
        VStack{
            Text("gg")
            ZStack{

//            Rectangle()
//                .fill(.yellow)
//                .frame(width:340, height: 190)
//                VStack{
//                    Text("id: 1")
//                    Text("Nome : bulbasaur")
//                    Text("types: [.grass, .poison]")
                    
                    
                }
            
            }
//            Rectangle()
//                .fill(.green)
//                .frame(width:340, height: 190)
//            Rectangle()
//                .fill(.red)
//                .frame(width:340, height: 190)
//            Rectangle()
//                .fill(.blue)
//                .frame(width:340, height: 190)
//            NavigationStack{
//                Text("POKEDEX@@@")
//                    .navigationTitle("POKEDEX!!!")
//                    .navigationBarTitleDisplayMode(.inline)
//                    .fontWeight(.semibold)
//                    .font(.title)
//                    .foregroundColor(.green)
            }
//                VStack(){
//                    Text("POKEDEX@@@")
//                    Text("POKEDEXyyy")
//                        .fontWeight(.semibold)
//                        .font(.title)
//                        .foregroundColor(.green)
//                }

        }
 }

//}

struct PokedexView_Previews: PreviewProvider {
    static var previews: some View {
        PokedexView()
    }
}
